extends Node2D

const PLAYER_SPEED := 260.0
const ENEMY_SPEED := 105.0
var player_pos := Vector2(390, 470)
var enemy_pos := Vector2(1040, 365)
var health := 75.0
var hunger := 60.0
var ammo := 15
var reserve := 45
var battery := 70.0
var flashlight_on := true
var aiming := false
var moving := false
var move_vec := Vector2.ZERO
var shot_cooldown := 0.0
var reload_time := 0.0
var game_over := false
var message := "ENCONTRE A SAÍDA DO LABORATÓRIO"

func _ready():
    get_viewport().size_changed.connect(queue_redraw)
    set_process(true)

func _process(delta):
    if game_over:
        queue_redraw()
        return
    hunger = maxf(0.0, hunger - delta * 0.10)
    if hunger <= 0:
        health = maxf(0.0, health - delta * 1.8)
    if flashlight_on:
        battery = maxf(0.0, battery - delta * 0.75)
        if battery <= 0: flashlight_on = false
    shot_cooldown = maxf(0.0, shot_cooldown - delta)
    if reload_time > 0:
        reload_time -= delta
        if reload_time <= 0:
            var need = 30 - ammo
            var take = mini(need, reserve)
            ammo += take
            reserve -= take
    player_pos += move_vec * PLAYER_SPEED * delta
    player_pos.x = clampf(player_pos.x, 80, 1200)
    player_pos.y = clampf(player_pos.y, 340, 585)

    # A criatura aproxima-se mais depressa quando está iluminada.
    var to_player = player_pos - enemy_pos
    var distance = to_player.length()
    var illuminated = flashlight_on and absf(to_player.angle()) < 0.48 and distance < 620
    var speed = ENEMY_SPEED * (1.8 if illuminated else 0.72)
    if distance > 52:
        enemy_pos += to_player.normalized() * speed * delta
    else:
        health = maxf(0.0, health - delta * 12.0)
    if health <= 0:
        game_over = true
        message = "FOSTE APANHADO — TOCA PARA RECOMEÇAR"
    queue_redraw()

func _draw():
    var s = get_viewport_rect().size
    # Fundo e camadas do laboratório
    draw_rect(Rect2(Vector2.ZERO, s), Color("#080d18"))
    draw_rect(Rect2(0, 0, 1280, 345), Color("#101a29"))
    # painéis e tubagem
    for x in range(0, 1280, 150):
        draw_rect(Rect2(x, 45, 5, 280), Color("#26364a"))
        draw_line(Vector2(x, 55), Vector2(x+110, 55), Color("#34445a"), 4)
    # janela de contenção azul
    draw_rect(Rect2(55, 155, 330, 220), Color("#142c45"), true, 8)
    draw_rect(Rect2(68, 168, 304, 194), Color("#071d37"), true, 5)
    draw_rect(Rect2(190, 175, 65, 180), Color("#087bb5"), true, 18)
    draw_rect(Rect2(199, 183, 47, 164), Color("#18bfff"), true, 15)
    draw_circle(Vector2(222, 263), 25, Color("#071827"))
    draw_line(Vector2(222, 285), Vector2(222, 330), Color("#071827"), 17)
    # placa LAB-03
    draw_rect(Rect2(510, 105, 255, 115), Color("#182331"))
    draw_string(ThemeDB.fallback_font, Vector2(535, 158), "LAB-03", HORIZONTAL_ALIGNMENT_LEFT, -1, 38, Color("#aab7c5"))
    draw_string(ThemeDB.fallback_font, Vector2(535, 191), "RESEARCH FACILITY", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("#8995a3"))
    # chão com perspectiva
    draw_polygon(PackedVector2Array([Vector2(0,350),Vector2(1280,350),Vector2(1280,720),Vector2(0,720)]), Color("#202632"))
    for y in range(365, 720, 48):
        draw_line(Vector2(0,y), Vector2(1280,y), Color("#39414c"), 2)
    for x in range(-300, 1600, 125):
        draw_line(Vector2(640,350), Vector2(x,720), Color("#343d49"), 2)
    # caixas e barreiras
    _crate(Vector2(700, 390), Vector2(150, 100))
    _crate(Vector2(925, 510), Vector2(210, 95))
    _crate(Vector2(110, 520), Vector2(115, 75))
    # porta vermelha ao fundo
    draw_rect(Rect2(850, 105, 145, 245), Color("#250d18"))
    draw_rect(Rect2(865, 118, 115, 220), Color("#5d1421"), false, 4)
    draw_rect(Rect2(860, 105, 12, 20), Color("#ff293d"))
    draw_rect(Rect2(980, 105, 12, 20), Color("#ff293d"))
    # feixe da lanterna
    if flashlight_on:
        var target = get_global_mouse_position()
        if target == Vector2.ZERO: target = Vector2(900, player_pos.y)
        var direction = Vector2.RIGHT
        if aiming: direction = (target - player_pos).normalized()
        var cone = PackedVector2Array([player_pos+Vector2(8,-12), player_pos+direction.rotated(-0.30)*650+Vector2(0,-80), player_pos+direction.rotated(0.30)*650+Vector2(0,80)])
        draw_colored_polygon(cone, Color(1.0,0.91,0.67,0.13))
        draw_line(player_pos+Vector2(15,-5), player_pos+direction*470, Color(1,0.94,0.76,0.28), 3)
    # monstro
    draw_circle(enemy_pos, 24, Color("#25252c"))
    draw_circle(enemy_pos+Vector2(-9,-8), 5, Color("#ff1e32"))
    draw_circle(enemy_pos+Vector2(9,-8), 5, Color("#ff1e32"))
    draw_line(enemy_pos+Vector2(-13,15), enemy_pos+Vector2(-32,40), Color("#30303a"), 9)
    draw_line(enemy_pos+Vector2(13,15), enemy_pos+Vector2(32,40), Color("#30303a"), 9)
    # jogador
    draw_circle(player_pos+Vector2(0,-32), 15, Color("#b9c1c9"))
    draw_rect(Rect2(player_pos+Vector2(-18,-18), Vector2(36,58)), Color("#26384b"), true, 7)
    draw_line(player_pos+Vector2(10,-5), player_pos+Vector2(54,-17), Color("#111820"), 10)
    draw_line(player_pos+Vector2(-8,35), player_pos+Vector2(-18,65), Color("#101820"), 12)
    draw_line(player_pos+Vector2(8,35), player_pos+Vector2(22,65), Color("#101820"), 12)
    # HUD
    _hud()
    # Controlos móveis
    _controls()
    if game_over:
        draw_rect(Rect2(0,0,1280,720), Color(0,0,0,0.72))
        draw_string(ThemeDB.fallback_font, Vector2(350,350), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color.WHITE)

func _crate(pos: Vector2, size: Vector2):
    draw_rect(Rect2(pos, size), Color("#303640"), true, 5)
    draw_rect(Rect2(pos+Vector2(8,8), size-Vector2(16,16)), Color("#202832"), false, 4)
    draw_line(pos+Vector2(12,12), pos+size-Vector2(12,12), Color("#59616b"), 4)
    draw_line(pos+Vector2(size.x-12,12), pos+Vector2(12,size.y-12), Color("#59616b"), 4)

func _bar(x: float, y: float, w: float, value: float, color: Color):
    draw_rect(Rect2(x,y,w,19), Color("#090d12"), true, 4)
    draw_rect(Rect2(x+4,y+4,(w-8)*value/100.0,11), color, true, 3)

func _hud():
    draw_string(ThemeDB.fallback_font, Vector2(75,34), "♥  VIDA: %d / 100" % int(health), HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color.WHITE)
    _bar(75,43,270,health,Color("#20d64b"))
    draw_string(ThemeDB.fallback_font, Vector2(75,91), "FOME: %d / 100" % int(hunger), HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)
    _bar(75,100,270,hunger,Color("#eaa52b"))
    draw_string(ThemeDB.fallback_font, Vector2(1035,34), "▰  %d / %d" % [ammo,reserve], HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(1035,76), "ENERGIA: %d%%" % int(battery), HORIZONTAL_ALIGNMENT_LEFT, -1, 21, Color.WHITE)
    _bar(1035,85,190,battery,Color("#24d34c"))
    draw_string(ThemeDB.fallback_font, Vector2(530,695), message, HORIZONTAL_ALIGNMENT_CENTER, 400, 16, Color("#d1d9e4"))

func _controls():
    # direcional
    draw_circle(Vector2(150,590), 77, Color(0.75,0.78,0.84,0.16))
    draw_circle(Vector2(150,590), 37, Color(0.82,0.85,0.9,0.35))
    draw_string(ThemeDB.fallback_font, Vector2(130,535), "▲", HORIZONTAL_ALIGNMENT_LEFT, -1, 23, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(130,665), "▼", HORIZONTAL_ALIGNMENT_LEFT, -1, 23, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(82,600), "◀", HORIZONTAL_ALIGNMENT_LEFT, -1, 23, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(200,600), "▶", HORIZONTAL_ALIGNMENT_LEFT, -1, 23, Color.WHITE)
    # botões
    _button(Vector2(1130,470), "◎")
    _button(Vector2(1210,575), "●")
    _button(Vector2(1055,610), "↗")
    _button(Vector2(1135,660), "↻")
    _button(Vector2(1210,410), "🔦")

func _button(pos: Vector2, label: String):
    draw_circle(pos, 39, Color(0.7,0.75,0.82,0.18))
    draw_arc(pos, 39, 0, TAU, 48, Color(0.85,0.9,0.96,0.65), 3)
    draw_string(ThemeDB.fallback_font, pos+Vector2(-13,9), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 29, Color.WHITE)

func _input(event):
    if event is InputEventScreenTouch:
        if event.pressed:
            _touch_down(event.position)
        else:
            move_vec = Vector2.ZERO
    elif event is InputEventScreenDrag:
        if event.position.x < 270:
            var v = event.position - Vector2(150,590)
            move_vec = Vector2(signf(v.x), 0) if absf(v.x) > 15 else Vector2.ZERO
    elif event is InputEventMouseButton and event.pressed:
        _touch_down(event.position)
    elif event is InputEventKey and event.pressed:
        if event.keycode == KEY_A or event.keycode == KEY_LEFT: move_vec = Vector2.LEFT
        if event.keycode == KEY_D or event.keycode == KEY_RIGHT: move_vec = Vector2.RIGHT
        if event.keycode == KEY_SPACE: shoot()
        if event.keycode == KEY_R: reload_weapon()
        if event.keycode == KEY_F: flashlight_on = not flashlight_on
    elif event is InputEventKey and not event.pressed:
        if event.keycode in [KEY_A,KEY_D,KEY_LEFT,KEY_RIGHT]: move_vec = Vector2.ZERO

func _touch_down(p: Vector2):
    if game_over:
        get_tree().reload_current_scene()
        return
    if p.x < 270:
        var v = p - Vector2(150,590)
        move_vec = Vector2(signf(v.x),0) if absf(v.x)>15 else Vector2.ZERO
    elif p.x > 990 and p.y > 540 and p.y < 650:
        shoot()
    elif p.x > 1080 and p.y > 635:
        reload_weapon()
    elif p.x > 1080 and p.y < 470:
        flashlight_on = not flashlight_on
    elif p.x > 980 and p.y < 535:
        aiming = not aiming

func shoot():
    if shot_cooldown > 0 or reload_time > 0 or ammo <= 0: return
    ammo -= 1
    shot_cooldown = 0.28
    if player_pos.distance_to(enemy_pos) < 470:
        enemy_pos += (enemy_pos-player_pos).normalized()*48
        # tiro causa dano simplificado; três acertos afastam e reiniciam o monstro
        enemy_pos += Vector2(0, -8)
        if randf() < 0.35:
            enemy_pos = Vector2(1040,365)

func reload_weapon():
    if reserve > 0 and ammo < 30 and reload_time <= 0:
        reload_time = 1.4
